package com.affinity.affinityteam.affinity.Notifications;

public class MyResponse {

    public int success;
}
